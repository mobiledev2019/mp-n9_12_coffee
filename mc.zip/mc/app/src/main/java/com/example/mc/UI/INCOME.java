package com.example.mc.UI;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Parcelable;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.text.InputType;
import android.widget.EditText;
import android.widget.Toast;

import com.example.mc.ADAPTER.ItemAdapter;
import com.example.mc.MODEL.item;
import com.example.mc.MODEL.item_order;
import com.example.mc.R;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;

import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;


public class INCOME extends AppCompatActivity  {
    private final static int REQUEST_CODE_1 = 1;
    private FirebaseFirestore db= FirebaseFirestore.getInstance();
    private CollectionReference collect=db.collection("item_info");
    private RecyclerView recyclerView;
    private ItemAdapter itemAdapter;
    private item i;
    private String m_Text = "";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.income);

        Toolbar toolbar =findViewById(R.id.income_toolbar);
        setSupportActionBar(toolbar);
        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setHomeAsUpIndicator(R.drawable.ic_arrow_back_black_24dp);
        setupRecycleView();
    }

    private void setupRecycleView() {
        Query query = collect.orderBy("price",Query.Direction.ASCENDING);
        FirestoreRecyclerOptions<item> options = new FirestoreRecyclerOptions.Builder<item>().
                setQuery(query,item.class)
                .build();
        itemAdapter = new ItemAdapter(options);
        recyclerView = findViewById(R.id.combine);
        recyclerView.setHasFixedSize(true);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        recyclerView.setLayoutManager(linearLayoutManager);
        recyclerView.setAdapter(itemAdapter);
        itemAdapter.SetOnItemClickListener(new ItemAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(DocumentSnapshot documentSnapshot, int position) {
                i =documentSnapshot.toObject(item.class);
                // open new activity
                CreateAlert();
            }
        });
    }
    private void CreateAlert(){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Ammout");
        final EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_NUMBER);
        builder.setView(input);
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                m_Text = input.getText().toString();
                item_order io = new item_order(i.getName(),i.getPrice(),Integer.parseInt(m_Text));
                Toast.makeText(getApplicationContext(),io.getName(),Toast.LENGTH_SHORT).show();
                Intent intent=new Intent();
                intent.putExtra("item_order", io);
                setResult(REQUEST_CODE_1,intent);
                finish();
            }
        });
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        builder.show();
    }
    @Override
    protected void onStop() {
        super.onStop();
        itemAdapter.stopListening();
    }

    @Override
    protected void onStart() {
        super.onStart();
        itemAdapter.startListening();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }
}
