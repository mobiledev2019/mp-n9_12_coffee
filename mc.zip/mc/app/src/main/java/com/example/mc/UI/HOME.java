package com.example.mc.UI;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.support.v7.widget.helper.ItemTouchHelper;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.mc.ADAPTER.ItemOrderAdapter;
import com.example.mc.MODEL.DayCount;
import com.example.mc.MODEL.item_order;
import com.example.mc.MODEL.order;
import com.example.mc.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

import java.text.SimpleDateFormat;
import java.util.Date;

public class HOME extends AppCompatActivity {
    private final static SimpleDateFormat stsf=new SimpleDateFormat("dd-MM-yyyy-hh-mm-ss");
    private final static SimpleDateFormat sdf=new SimpleDateFormat("dd-MM-yyyy");
    private final static SimpleDateFormat stf=new SimpleDateFormat("hh-mm-ss");
    private FirebaseFirestore db=FirebaseFirestore.getInstance();
    private CollectionReference orderRef = db.collection("order");
    private CollectionReference dayRef = db.collection("day");
    private final static int REQUEST_CODE_1 = 1;
    private ItemOrderAdapter itemOrderAdapter;
    DrawerLayout Drawer;
    RecyclerView recyclerView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.home);
        Drawer =findViewById(R.id.Drawer);
        //Init Home toolbar
        HomeToolbar();
        // Init Bottom navigation
        //BottomNav();


        setupRecycleView();
        setupButtonSubmit();
    }

    private void setupButtonSubmit() {
        Button submit = findViewById(R.id.submit);
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                setupConnection();
            }
        });
    }
    private void setupConnection(){
        final Date date =new Date(System.currentTimeMillis());
        final order or=new order(sdf.format(date).toString(),stf.format(date),itemOrderAdapter.getItemOrderList());
        orderRef.document(stsf.format(date)).set(or).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void aVoid) {
                checkday(date,or);
                Toast.makeText(getApplicationContext(),"SUCCESS",Toast.LENGTH_LONG).show();

            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(getApplicationContext(),"FAILURE",Toast.LENGTH_LONG).show();
            }
        });
    }
    private void checkday(Date date, final order or){
        final String day=sdf.format(date).toString();
        dayRef.document(day).get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
            @Override
            public void onSuccess(DocumentSnapshot documentSnapshot) {
                if(documentSnapshot.exists()){
                    dayRef.document(day).update("income",(Long) documentSnapshot.get("income")+or.getTotalPrice(),"itemcount",(Long) documentSnapshot.get("itemcount")+or.getTotalAmmount());



                }else dayRef.document(day).set(new DayCount(day,or.getTotalPrice(),or.getTotalAmmount()));


            }
        });

    }
    private void HomeToolbar(){
        Toolbar toolbar = findViewById(R.id.Home_Toolbar);
        setSupportActionBar(toolbar);
        ActionBar actionBar =getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setHomeAsUpIndicator(R.drawable.ic_menu_black_24dp);
    }

    private void setupRecycleView(){
        recyclerView =findViewById(R.id.Container);
        recyclerView.setHasFixedSize(true);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        recyclerView.setLayoutManager(linearLayoutManager);
        itemOrderAdapter=new ItemOrderAdapter();
        recyclerView.setAdapter(itemOrderAdapter);

        ItemTouchHelper itemTouchHelper =new ItemTouchHelper(new ItemTouchHelper.SimpleCallback(0,ItemTouchHelper.LEFT|ItemTouchHelper.RIGHT) {
            @Override
            public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder viewHolder1) {
                return false;
            }

            @Override
            public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int i) {
                int position =viewHolder.getAdapterPosition();
                itemOrderAdapter.deleteElement(position);
            }
        });
        itemTouchHelper.attachToRecyclerView(recyclerView);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.rightmenu,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()){
            case android.R.id.home :
                Drawer.openDrawer(Gravity.START);
                return true;
            case R.id.add_item :
                startActivityForResult(new Intent(this,INCOME.class),REQUEST_CODE_1);
                return true;

        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode){
            case REQUEST_CODE_1:
                item_order io= (item_order) data.getParcelableExtra("item_order");
                itemOrderAdapter.addElement(io);
                break;
        }
    }
}
