package com.example.mc.ADAPTER;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.mc.MODEL.item_order;
import com.example.mc.R;

import java.util.ArrayList;
import java.util.List;

public class ItemOrderAdapter extends RecyclerView.Adapter<ItemOrderAdapter.ItemOrderHolder> {
    private List<item_order> itemOrderList=new ArrayList<>();

    public List<item_order> getItemOrderList() {
        return itemOrderList;
    }

    public ItemOrderAdapter() {
    }

    @NonNull
    @Override
    public ItemOrderHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View itemView = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_order_card,viewGroup,false);
        return new ItemOrderHolder(itemView);
    }

    public void deleteElement(int position){
        itemOrderList.remove(position);
        notifyDataSetChanged();
    }
    public void addElement(item_order io){
        itemOrderList.add(io);
        notifyDataSetChanged();
    }
    @Override
    public void onBindViewHolder(@NonNull ItemOrderHolder itemOrderHolder, int i) {
        item_order io = itemOrderList.get(i);
        itemOrderHolder.ammount.setText("ammount :"+String.valueOf(io.getAmmount())+" pcs ");
        itemOrderHolder.name.setText(io.getName());
        itemOrderHolder.price.setText("price/unit :"+ String.valueOf(io.getPrice())+" $ ");

    }
    @Override
    public int getItemCount() {
        return itemOrderList.size();
    }

    public class ItemOrderHolder extends RecyclerView.ViewHolder  {
        TextView name,ammount,price;
        public ItemOrderHolder(@NonNull View itemView) {
            super(itemView);
            name=itemView.findViewById(R.id.item_order_name);
            ammount=itemView.findViewById(R.id.item_ammount);
            price=itemView.findViewById(R.id.price_pre_item);
        }
    }
}
